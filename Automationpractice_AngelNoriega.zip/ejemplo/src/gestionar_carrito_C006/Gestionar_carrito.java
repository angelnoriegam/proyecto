package gestionar_carrito_C006;

import org.openqa.selenium.WebDriver;
//import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Time.time;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*; 
import org.junit.Test;


/*
 * Esta clase define el caso de prueba "C006 Gestionar carrito" en la tienda virtual

 * @author: Angel NOriega

 * @version: 1.0
 
 * @Fecha: 31/12/2020

 */

public class Gestionar_carrito {
	

	 public static void main(String[] args) {
		 	
		 	time tiempo = new time();
		 
		 	WebDriver driver;
			String baseUrl= "http://automationpractice.com/index.php"; 
			String chromePath = System.getProperty("webdriver.chrome.driver","C:\\Users\\Fabricio\\eclipse\\java-2020-12\\eclipse\\chromedriver.exe"); 
			
			System.setProperty("webdriver.chrome.driver", chromePath); 
			
			String resultado = "";
			
			String valor_esperado= "2";
			String valor_actual= "";
			String total = "";
			
						
			driver = new ChromeDriver(); 
			driver.get(baseUrl); //Url de la p�gina que va abrir
			driver.manage().window().maximize(); //abrir la ventana full tama�o
			tiempo.Tiempo(2000);
		 
		
				
/*		System.setProperty("webdriver.chrome.driver","C:\\Users\\Fabricio\\eclipse\\java-2020-12\\eclipse\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize(); //abrir la ventana full tama�o
		driver.get("http://automationpractice.com/index.php"); //Url de la p�gina que va abrir
		tiempo.Tiempo(2000); */
		

		//BUSQUEDA DEL PRIMER PRODCUTO
		driver.findElement(By.id("search_query_top")).click();
		tiempo.Tiempo(2000);
				
				
		driver.findElement(By.id("search_query_top")).sendKeys("Blouse");
		tiempo.Tiempo(2000);
		
		//Submit
			driver.findElement(By.xpath("//*[@id=\"searchbox\"]/button")).click();
			tiempo.Tiempo(2000);
				
						
		//Muestra los productos y selecciona  
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[1]/div/a[1]/img")).click();
		tiempo.Tiempo(2000);


		//Hago referencia al "iFrame" para poder Presionar el bot�n ADD CARD
		//driver.switchTo().frame("fancybox-frame1609644189737");
		WebElement iFrame= driver.findElement(By.tagName("iframe"));
		driver.switchTo().frame(iFrame);
		tiempo.Tiempo(5000);
		
		driver.findElement(By.xpath("/html/body/div/div/div[3]/form/div/div[3]/div/p/button")).click();
		tiempo.Tiempo(2000);

	//Cierra la ventana Modal
	//	driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]")).click();
	//	tiempo.Tiempo(2000);
					
		driver.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[1]/span")).click();
		tiempo.Tiempo(2000);
			
		
		
		
	//Datos de BUSQUEDA DEL SEGUNDO PRODCUTO
				driver.findElement(By.id("search_query_top")).click();
				tiempo.Tiempo(2000);
						
		//		driver.findElement(By.id("search_query_top")).sendKeys("");
		//		tiempo.Tiempo(2000);
				
				driver.findElement(By.id("search_query_top")).clear();
				tiempo.Tiempo(2000);
				
				driver.findElement(By.id("search_query_top")).sendKeys("Printed Dress");
				tiempo.Tiempo(2000);
				
				//Submit
					driver.findElement(By.xpath("//*[@id=\"searchbox\"]/button")).click();
					tiempo.Tiempo(2000);
		
	//Selecciona el producto 
				driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li[2]/div/div[1]/div/a[1]/img")).click();
				tiempo.Tiempo(2000);

	//Presiona el bot�n ADD CARD	
				
				//driver.switchTo().frame("fancybox-frame1609644189737");
				WebElement iFrame2= driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(iFrame2);
				tiempo.Tiempo(5000);
				
				driver.findElement(By.xpath("/html/body/div/div/div[3]/form/div/div[3]/div/p/button")).click();
				tiempo.Tiempo(3000);	
				
				//Cierra la ventana Modal
				driver.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[1]/span")).click();
				tiempo.Tiempo(2000);
				
				//*[@id="layer_cart"]/div[1]/div[1]/span		
	//�COMO REALIZAR LAS VALIDACIONES QUE SE AGREG� EN EL CARRITO?
									
						
				//Obtener cantidad de producto
				valor_actual = driver.findElement(By.xpath("//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a/span[1]")).getText();
				//System.out.println("valor actual es: " + valor_actual); 
								
					if (valor_actual.contentEquals(valor_esperado)){
						System.out.println("Prueba Pasada! la cantidad de producto en carrito es: " + valor_actual + " es igual a " + valor_esperado);
					}else 	{
						System.out.println("Prueba Fallida! la cantidad de producto en carrito es: " + valor_actual + " No es igual a " + valor_esperado);
					}
				
					
			driver.close();
		//System.out.println("Seguir comprando");
		//driver.close();

	}

}
