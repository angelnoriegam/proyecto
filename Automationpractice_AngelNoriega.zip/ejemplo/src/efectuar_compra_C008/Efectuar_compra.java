package efectuar_compra_C008;


import org.openqa.selenium.WebDriver;
//import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Time.time;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*; 
import org.junit.Test;


/*
 * Esta clase define el caso de prueba "C008	Efectuar Compra" en la tienda virtual

 * @author: Angel NOriega

 * @version: 1.0
 
 * @Fecha: 02/01/2020

 */

public class Efectuar_compra {
	
	public static void main(String[] args) {
		
		time tiempo = new time();
		
		WebDriver driver;
		String baseUrl= "http://automationpractice.com/index.php"; 
		String chromePath = System.getProperty("webdriver.chrome.driver","C:\\Users\\Fabricio\\eclipse\\java-2020-12\\eclipse\\chromedriver.exe"); 
		
		System.setProperty("webdriver.chrome.driver", chromePath); 
		
		String pagina_esperada = "Order - My Store";
		String pagina_resultante = "";
		String resultado = "";
		
		String valor_pedido_esperado= "$29.00";
		String total = "";
		
		
		driver = new ChromeDriver(); 
		driver.get(baseUrl); //Url de la p�gina que va abrir
		driver.manage().window().maximize(); //abrir la ventana full tama�o
		tiempo.Tiempo(2000);
		
		//funciona
	/*	System.setProperty("webdriver.chrome.driver","C:\\Users\\Fabricio\\eclipse\\java-2020-12\\eclipse\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(); 
		driver.manage().window().maximize(); //abrir la ventana full tama�o
		driver.get("http://automationpractice.com/index.php"); //Url de la p�gina que va abrir
		tiempo.Tiempo(2000); */
		
		//Selecciona el producto 2 
		driver.findElement(By.xpath("//*[@id=\"homefeatured\"]/li[2]/div/div[1]/div/a[1]/img")).click();
		tiempo.Tiempo(2000);

		//Presiona el bot�n ADD CARD	
		driver.findElement(By.xpath("//*[@id=\"add_to_cart\"]")).click();
		tiempo.Tiempo(2000);
		
		//Boton de Proceed to chekout
		driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a")).click();
		tiempo.Tiempo(2000);
		
				
		//Boton de Proceed to chekout - 01. Summary
				driver.findElement(By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]")).click();
				tiempo.Tiempo(2000);
		
			pagina_resultante = driver.getTitle();
			
			resultado = (pagina_resultante.contentEquals(pagina_esperada)?"Continuar" + pagina_resultante : "Sesion");
			
			if (resultado == "Sesion") {
						//Datos de loguero
						driver.findElement(By.id("email")).click();
						tiempo.Tiempo(2000);
						
						
						driver.findElement(By.id("email")).sendKeys("angel.noriega.m@gmail.com");
						tiempo.Tiempo(2000);
						
						
						driver.findElement(By.id("passwd")).click();
						tiempo.Tiempo(2000);
						
						
						driver.findElement(By.id("passwd")).sendKeys("dF20@852t");
						tiempo.Tiempo(2000);
																	
						//Submit
						driver.findElement(By.xpath("//*[@id=\"SubmitLogin\"]/span")).click();
						tiempo.Tiempo(3000);
						
			    	} /*else {
			         System.out.println("Sesi�n Iniciada Correctamente");
			         driver.close();
			      }	*/	
				
			//Agregar comentario a pedido - - 03. Address
			driver.findElement(By.tagName("textarea")).click();
			tiempo.Tiempo(3000);
			
			driver.findElement(By.tagName("textarea")).sendKeys("Este es un comentario a pedido");
			tiempo.Tiempo(3000);
			
			//Boton de Proceed to chekout - 03. Address
			driver.findElement(By.xpath("//*[@id=\"center_column\"]/form/p/button")).click();
			tiempo.Tiempo(2000);
			
			
			//Click en Terms of service
			driver.findElement(By.xpath("//*[@id=\"cgv\"]")).click();
			tiempo.Tiempo(3000);
			
			//Boton de Proceed to chekout - 04. Shipping
			driver.findElement(By.xpath("//*[@id=\"form\"]/p/button")).click();
			tiempo.Tiempo(3000);
			
			
			//Extraigo el valor de la compra - 05. Payment
			String valor_compra = driver.findElement(By.xpath("//*[@id=\"total_price\"]")).getText();
			System.out.println(valor_compra); // extraigo el valor de la compra
			tiempo.Tiempo(2000);
			
			//Comparo si son iguales los montos antes de pagar la orden
						
			total = (valor_compra.contentEquals(valor_pedido_esperado)?"Continuar" + valor_compra : "Diferencias entre montos");
			
				if (total == "Diferencias entre montos") {				
				System.out.println("Error en diferencias de montos");
				driver.close();
				}
				
			//Click Bot�n Pay by bank wire
			driver.findElement(By.xpath("//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a")).click();
			tiempo.Tiempo(2000);
			
			//Click Bot�n I confirm my order
			driver.findElement(By.tagName("button")).click();
			tiempo.Tiempo(3000);
			
			
			System.out.println("Flujo completado y pago correcto exitosamente");
		driver.close();

	}
}
