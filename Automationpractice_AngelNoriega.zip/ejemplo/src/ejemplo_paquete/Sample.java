package ejemplo_paquete;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver; //
import org.openqa.selenium.WebElement; //
import org.openqa.selenium.chrome.ChromeDriver; //

import Time.time;


public class Sample
{
		
public static void main(String[] args) 
{
	time tiempo = new time();
	
// Configuring the system properties of chrome driver
System.setProperty("webdriver.chrome.driver", "C:\\Users\\Fabricio\\eclipse\\java-2020-12\\eclipse\\chromedriver.exe");

//Initializing the browser driver
WebDriver driver = new ChromeDriver();

driver.manage().window().maximize(); //abrir la ventana full tama�o

//Navigating through a particular website
driver.get("http://automationpractice.com/index.php");

tiempo.Tiempo(15000);

System.out.println("Selenium Webdriver Script in Chrome");
driver.close();

}
}

