package ejemplo_paquete;

import org.openqa.selenium.WebDriver;
//import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Time.time;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*; 
import org.junit.Test;


/*
 * Esta clase define el caso de prueba "C001 Registrarse" en la tienda virtual

 * @author: Angel NOriega

 * @version: 1.0
 
 * @Fecha: 29/12/2020

 */

public class ejemplo1{
	
	public static void main(String[] args) 
	{
		time tiempo = new time();
		
		WebDriver driver;
		String baseUrl= "http://automationpractice.com/index.php"; 
		String chromePath = System.getProperty("webdriver.chrome.driver","C:\\Users\\Fabricio\\eclipse\\java-2020-12\\eclipse\\chromedriver.exe"); 
			
		System.setProperty("webdriver.chrome.driver", chromePath); 
			
		driver = new ChromeDriver(); 
		driver.get(baseUrl); //Url de la p�gina que va abrir
		driver.manage().window().maximize(); //abrir la ventana full tama�o
		tiempo.Tiempo(2000);
	

		driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
		tiempo.Tiempo(2000);
	
		driver.findElement(By.id("email_create")).click();
		tiempo.Tiempo(2000);
		
		//Correo electr�nico con que el usuario se registrar� (No existen en BD)
		driver.findElement(By.id("email_create")).sendKeys("aamedori.m@gmail.com");
		tiempo.Tiempo(2000);
		
		//Submit
		driver.findElement(By.xpath("//*[@id=\"SubmitCreate\"]/span")).click();
		tiempo.Tiempo(2000);
	
	/*-----REGISTRO DEL FORMULARIO ----*/
		
			driver.findElement(By.xpath("//*[@id=\"id_gender1\"]")).click();
			tiempo.Tiempo(2000); 
	
	
		//referencia First name
			driver.findElement(By.id("customer_firstname")).click();
			tiempo.Tiempo(2000);
			driver.findElement(By.id("customer_firstname")).sendKeys("Alfredo");
			tiempo.Tiempo(2000);
	
	
		//referencia First name
			driver.findElement(By.id("customer_lastname")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("customer_lastname")).sendKeys("Medori");
			tiempo.Tiempo(2000);
			
			
		//Password Correo electr�nico 	
			driver.findElement(By.id("passwd")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("passwd")).sendKeys("3562987");
			tiempo.Tiempo(2000);
			
			
		//Date of Birth	- DIA
			driver.findElement(By.id("days")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("days")).sendKeys("15");
			tiempo.Tiempo(2000);	
			
			
		//Date of Birth	- MES
			driver.findElement(By.id("months")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("months")).sendKeys("February");
			tiempo.Tiempo(2000);
			
		//Date of Birth	- A�O
			driver.findElement(By.id("years")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("years")).sendKeys("2020");
			tiempo.Tiempo(2000);
			
			
		//env�o de newsletter
			driver.findElement(By.xpath("//*[@id=\"newsletter\"]")).click();
			tiempo.Tiempo(3000);
			
						
		//First name *	
			driver.findElement(By.id("firstname")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("firstname")).sendKeys(" - Ejemplo de First name");
			tiempo.Tiempo(2000);
			
			
		//Last name *	
			driver.findElement(By.id("lastname")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("lastname")).sendKeys(" - Ejemplo de Last name");
			tiempo.Tiempo(2000);
			
		//Company	
			driver.findElement(By.id("company")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("company")).sendKeys("Ejemplo de Company");
			tiempo.Tiempo(2000);
			
			
		//Address *	
			driver.findElement(By.id("address1")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("address1")).sendKeys("San Miguel 15088, calle 5530 Chamaya 174, Personal");
			tiempo.Tiempo(2000);
			
		//Address (Line 2)	
			driver.findElement(By.id("address2")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("address2")).sendKeys("Ejemplo de Address 2, San Miguel 15088, calle 5530 Chamaya 174, Personal");
			tiempo.Tiempo(2000);
			
			
		//City *
			driver.findElement(By.id("city")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("city")).sendKeys("Ejemplo de City");
			tiempo.Tiempo(2000);
			
			
		//State *	
			driver.findElement(By.id("id_state")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("id_state")).sendKeys("Montana");
			tiempo.Tiempo(2000);
			
			
		//Zip/Postal Code *	
			driver.findElement(By.id("postcode")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("postcode")).sendKeys("3562987");
			tiempo.Tiempo(2000);
			
			
		//Country *
			driver.findElement(By.id("id_country")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("id_country")).sendKeys("United States");
			tiempo.Tiempo(2000);
			
		//Additional information	
			driver.findElement(By.id("other")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("other")).sendKeys("Prueba de Additional information");
			tiempo.Tiempo(2000);
			
			
		//Home phone
			driver.findElement(By.id("phone")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("phone")).sendKeys("365896231");
			tiempo.Tiempo(2000);
			
			
		//Mobile phone *	
			driver.findElement(By.id("phone_mobile")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("phone_mobile")).sendKeys("96523475");
			tiempo.Tiempo(2000);
			
			
		//Assign an address alias for future reference. *
			driver.findElement(By.id("alias")).click();
			tiempo.Tiempo(2000);
			
			driver.findElement(By.id("alias")).sendKeys(" - Mi Direccion actual");
			tiempo.Tiempo(2000);
			
			
			/*driver.findElement(By.xpath("//*[@id=\"submitAccount\"]/span")).click();
			tiempo.Tiempo(2000); */
			
			
	System.out.println("Prueba Pasada");
	driver.close();

	}
}


