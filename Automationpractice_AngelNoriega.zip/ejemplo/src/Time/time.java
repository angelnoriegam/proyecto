package Time;

public class time {
	public void Tiempo(int seconds) {
		
	    try {
	    	Thread.sleep(seconds);
	    }catch (InterruptedException e) {
	    	e.printStackTrace();
	    	
	    }
}

}
