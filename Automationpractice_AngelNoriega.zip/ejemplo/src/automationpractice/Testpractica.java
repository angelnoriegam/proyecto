package automationpractice;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//import java.util.List;
//import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Time.time;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;


public class Testpractica {
		
	ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	ExtentTest logger;
	WebDriver driver;
	time wait = new time();
	SoftAssert softAssert = new SoftAssert();
	
	
    @BeforeTest
	public void startReport(){
		
		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") +"/test-output/automaticepractica-2020-01-04-V1.html");
		extent = new ExtentReports ();
		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("Website", "Automationpractice");
		extent.setSystemInfo("Environment", "Test");
		extent.setSystemInfo("User Name", "Angel Noriega");
		
		htmlReporter.config().setDocumentTitle("Automation practice REPORT");
		htmlReporter.config().setReportName("Automation practice REPORT");
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setTheme(Theme.STANDARD);
		
	}
		
		
	@BeforeMethod
		public void setup() {
			
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Fabricio\\eclipse\\java-2020-12\\eclipse\\chromedriver.exe");
			driver = new ChromeDriver(); 
			driver.get("http://automationpractice.com/index.php"); //Url de la p�gina que va abrir
			driver.manage().window().maximize(); //abrir la ventana full tama�o
			wait.Tiempo(2000);
			
		}			
			
		
//*************************** CASO DE PRUEBA C001 REGISTRO priority=1 *************************************
//*************************** CASO DE PRUEBA C001 REGISTRO priority=1 *************************************
		
	@Test(enabled=true,priority=1)
		public void Registrarse() throws Exception {
		logger = extent.createTest("Registro de Usuario");
			
			
		driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
		wait.Tiempo(3000);
	
		driver.findElement(By.id("email_create")).click();
		wait.Tiempo(3000);
		
		//Correo electr�nico con que el usuario se registrar� (No existen en BD)
		driver.findElement(By.id("email_create")).sendKeys("aamedori.m@gmail.com");
		wait.Tiempo(3000);
		
		//Submit
		driver.findElement(By.xpath("//*[@id=\"SubmitCreate\"]/span")).click();
		wait.Tiempo(3000);
	    // Registro de Evento
		logger.log(Status.INFO, "Correo verificado");
		
	/*-----REGISTRO DEL FORMULARIO ----*/
		
			driver.findElement(By.xpath("//*[@id=\"id_gender1\"]")).click();
			wait.Tiempo(2000); 
	
		//referencia First name
			driver.findElement(By.id("customer_firstname")).click();
			wait.Tiempo(2000);
			driver.findElement(By.id("customer_firstname")).sendKeys("Alfredo");
			wait.Tiempo(2000);
	
	
		//referencia First name
			driver.findElement(By.id("customer_lastname")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("customer_lastname")).sendKeys("Medori");
			wait.Tiempo(2000);
			
			
		//Password Correo electr�nico 	
			driver.findElement(By.id("passwd")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("passwd")).sendKeys("3562987");
			wait.Tiempo(2000);
			
			
		//Date of Birth	- DIA
			driver.findElement(By.id("days")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("days")).sendKeys("15");
			wait.Tiempo(2000);	
			
			
		//Date of Birth	- MES
			driver.findElement(By.id("months")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("months")).sendKeys("February");
			wait.Tiempo(2000);
			
		//Date of Birth	- A�O
			driver.findElement(By.id("years")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("years")).sendKeys("2020");
			wait.Tiempo(2000);
			
			
		//env�o de newsletter
			driver.findElement(By.xpath("//*[@id=\"newsletter\"]")).click();
			wait.Tiempo(3000);
			
						
		//First name *	
			driver.findElement(By.id("firstname")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("firstname")).sendKeys(" - Ejemplo de First name");
			wait.Tiempo(2000);
			
			
		//Last name *	
			driver.findElement(By.id("lastname")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("lastname")).sendKeys(" - Ejemplo de Last name");
			wait.Tiempo(2000);
			
		//Company	
			driver.findElement(By.id("company")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("company")).sendKeys("Ejemplo de Company");
			wait.Tiempo(2000);
			
			
		//Address *	
			driver.findElement(By.id("address1")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("address1")).sendKeys("San Miguel 15088, calle 5530 Chamaya 174, Personal");
			wait.Tiempo(2000);
			
		//Address (Line 2)	
			driver.findElement(By.id("address2")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("address2")).sendKeys("Ejemplo de Address 2, San Miguel 15088, calle 5530 Chamaya 174, Personal");
			wait.Tiempo(2000);
			
			
		//City *
			driver.findElement(By.id("city")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("city")).sendKeys("Ejemplo de City");
			wait.Tiempo(2000);
			
			
		//State *	
			driver.findElement(By.id("id_state")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("id_state")).sendKeys("Montana");
			wait.Tiempo(2000);
			
			
		//Zip/Postal Code *	
			driver.findElement(By.id("postcode")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("postcode")).sendKeys("3562987");
			wait.Tiempo(2000);
			
			
		//Country *
			driver.findElement(By.id("id_country")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("id_country")).sendKeys("United States");
			wait.Tiempo(2000);
			
		//Additional information	
			driver.findElement(By.id("other")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("other")).sendKeys("Prueba de Additional information");
			wait.Tiempo(2000);
			
		//Home phone
			driver.findElement(By.id("phone")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("phone")).sendKeys("365896231");
			wait.Tiempo(2000);
			
		//Mobile phone *	
			driver.findElement(By.id("phone_mobile")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("phone_mobile")).sendKeys("96523475");
			wait.Tiempo(2000);
			
		//Assign an address alias for future reference. *
			driver.findElement(By.id("alias")).click();
			wait.Tiempo(2000);
			
			driver.findElement(By.id("alias")).sendKeys(" - Mi Direccion actual");
			wait.Tiempo(2000);
			logger.log(Status.INFO, "llenado de formulario");	
			
			/*driver.findElement(By.xpath("//*[@id=\"submitAccount\"]/span")).click();
			tiempo.Tiempo(2000); */	
			//logger = extent.createTest("Prueba Pasada");
			//Registro de evento
			logger.log(Status.INFO, "Usuario registrado");
			//System.out.println("Prueba Pasada");
			//driver.quit();
			
			}
		
		
//*************************** CASO DE PRUEBA C002 Iniciar sesi�n � Cliente registrado; priority=2 *************************************
//*************************** CASO DE PRUEBA C002 Iniciar sesi�n � Cliente registrado; priority=2 *************************************
				
	@Test(enabled=true,priority=2)
		public void cliente_registrado() throws Exception {
		logger = extent.createTest("Cliente Registrado");		
		
		
		String pagina_esperada = "My account - My Store";
		String pagina_resultante = "";
		 
		 /*		time tiempo = new time();		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Fabricio\\eclipse\\java-2020-12\\eclipse\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize(); //abrir la ventana full tama�o
		driver.get("http://automationpractice.com/index.php"); //Url de la p�gina que va abrir
		tiempo.Tiempo(2000);
		

		*/		
				
		driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
		wait.Tiempo(2000);

		//Datos del formulario de loguero
		
		/*Email*/
		driver.findElement(By.id("email")).click();
		wait.Tiempo(2000);
		
		
		driver.findElement(By.id("email")).sendKeys("angel.noriega.m@gmail.com");
		wait.Tiempo(2000);
		
		/*Password*/
		driver.findElement(By.id("passwd")).click();
		wait.Tiempo(2000);
		
		driver.findElement(By.id("passwd")).sendKeys("dF20@852t");
		wait.Tiempo(2000);
		logger.log(Status.INFO, "Ingreso credenciales de acceso");
							
		//Submit
		driver.findElement(By.xpath("//*[@id=\"SubmitLogin\"]/span")).click();
		wait.Tiempo(3000);
		logger.log(Status.INFO, "Submit");
		 

		pagina_resultante = driver.getTitle(); //obtengo el valor del t�tulo de la pagina para compararlo con el valor esperado
		System.out.println(pagina_resultante.contentEquals(pagina_esperada)?"Prueba Pasada - Sesi�n Iniciada Correctamente " + pagina_resultante : "Prueba Fallada -Sesi�n FALLADA");
		//driver.close();
		
		//Obtener cantidad de producto
			if (pagina_resultante.contentEquals(pagina_esperada)){
				// Registro de Evento exitoso
				logger.log(Status.INFO, "Prueba Pasada - Usuario Logueado con Exito");
				//System.out.println("Prueba Pasada! la cantidad de producto en carrito es: " + valor_actual + " es igual a " + valor_esperado);
			}else 	{
				// Registro de Evento NO exitoso
				logger.log(Status.INFO, "Prueba NO Pasada - Usuario NO Logueado");
				//System.out.println("Prueba Fallida! la cantidad de producto en carrito es: " + valor_actual + " No es igual a " + valor_esperado);
			}
		
		//	logger.log(Status.INFO, "Correo vErificado");
		

	 }

  			
//*************************** CASO DE PRUEBA C006 GESTIONAR CARRITO; priority=3 *************************************
//*************************** CASO DE PRUEBA C006 GESTIONAR CARRITO; priority=3 *************************************
		
	@Test(enabled=true,priority=3)
		public void Gestionar_carrito() throws Exception {
		logger = extent.createTest("Gestionar Carrito");		
		
//		String resultado = "";
		
		String valor_esperado= "2";
		String valor_actual= "";
//		String total = "";
		
		
		//BUSQUEDA DEL PRIMER PRODCUTO
				driver.findElement(By.id("search_query_top")).click();
				wait.Tiempo(2000);
						
						
				driver.findElement(By.id("search_query_top")).sendKeys("Blouse");
				wait.Tiempo(2000);
				
				//Submit
					driver.findElement(By.xpath("//*[@id=\"searchbox\"]/button")).click();
					wait.Tiempo(2000);
					
					logger.log(Status.INFO, "Buscar Pruducto 1");	
								
				//Muestra los productos y selecciona  
				driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[1]/div/a[1]/img")).click();
				wait.Tiempo(2000);


				//Hago referencia al "iFrame" para poder Presionar el bot�n ADD CARD
				//driver.switchTo().frame("fancybox-frame1609644189737");
				WebElement iFrame= driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(iFrame);
				wait.Tiempo(5000);
				
				driver.findElement(By.xpath("/html/body/div/div/div[3]/form/div/div[3]/div/p/button")).click();
				wait.Tiempo(2000);
				
				logger.log(Status.INFO, "Agrega al carrito");

			//Cierra la ventana Modal
			//	driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]")).click();
			//	tiempo.Tiempo(2000);
							
				driver.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[1]/span")).click();
				wait.Tiempo(4000);
					
						
			//Datos de BUSQUEDA DEL SEGUNDO PRODCUTO
						driver.findElement(By.id("search_query_top")).click();
						wait.Tiempo(2000);
								
				//		driver.findElement(By.id("search_query_top")).sendKeys("");
				//		tiempo.Tiempo(2000);
						
						driver.findElement(By.id("search_query_top")).clear();
						wait.Tiempo(2000);
						
						driver.findElement(By.id("search_query_top")).sendKeys("Printed Dress");
						wait.Tiempo(2000);
						
						//Submit
							driver.findElement(By.xpath("//*[@id=\"searchbox\"]/button")).click();
							wait.Tiempo(2000);
							logger.log(Status.INFO, "Buscar Pruducto 2");		
							
				
			//Selecciona el producto 
						driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li[2]/div/div[1]/div/a[1]/img")).click();
						wait.Tiempo(2000);

			//Presiona el bot�n ADD CARD	
						
						//driver.switchTo().frame("fancybox-frame1609644189737");
						WebElement iFrame2= driver.findElement(By.tagName("iframe"));
						driver.switchTo().frame(iFrame2);
						wait.Tiempo(5000);
						
						driver.findElement(By.xpath("/html/body/div/div/div[3]/form/div/div[3]/div/p/button")).click();
						wait.Tiempo(3000);	
						
						logger.log(Status.INFO, "Agrega al carrito");
						
						//Cierra la ventana Modal
						driver.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[1]/span")).click();
						wait.Tiempo(2000);
						
				//VALIDACION QUE SE AGREG� EN EL CARRITO									
								
						//Obtener cantidad de producto del carrito
						valor_actual = driver.findElement(By.xpath("//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a/span[1]")).getText();
						//System.out.println("valor actual es: " + valor_actual); 
										
							if (valor_actual.contentEquals(valor_esperado)){								
								//System.out.println("Prueba Pasada! la cantidad de producto en carrito es: " + valor_actual + " es igual a " + valor_esperado);
								logger.log(Status.INFO, "2 Productos agregados correctamente");
							}else 	{
								//System.out.println("Prueba Fallida! la cantidad de producto en carrito es: " + valor_actual + " No es igual a " + valor_esperado);
								logger.log(Status.INFO, "No se agregaron 2 Productos");
							}
		
		
	}	
		
//*************************** CASO DE PRUEBA C008 Efectuar_compra; priority=3 *************************************
//*************************** CASO DE PRUEBA C008 Efectuar_compra; priority=3 *************************************
	
				
	@Test(enabled=true,priority=4)
		public void Efectuar_compra() throws Exception {
		logger = extent.createTest("Efectuar_compra");			
		
		
				String pagina_esperada = "Order - My Store";
				String pagina_resultante = "";
				String resultado = "";
				
				String valor_pedido_esperado= "$29.00";
				String total = "";
				
				
				//Selecciona el producto 2 
				driver.findElement(By.xpath("//*[@id=\"homefeatured\"]/li[2]/div/div[1]/div/a[1]/img")).click();
				wait.Tiempo(2000);

				logger.log(Status.INFO, "Selecciona producto");	
				
				//Presiona el bot�n ADD CARD	
				driver.findElement(By.xpath("//*[@id=\"add_to_cart\"]")).click();
				wait.Tiempo(2000);
				
				logger.log(Status.INFO, "Agrega Producto a carrito");	
				
				//Boton de Proceed to chekout
				driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a")).click();
				wait.Tiempo(2000);
				
						
				//Boton de Proceed to chekout - 01. Summary
						driver.findElement(By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]")).click();
						wait.Tiempo(2000);
						
						logger.log(Status.INFO, "Etapa 01. Summary");	
						
					pagina_resultante = driver.getTitle();
					
					resultado = (pagina_resultante.contentEquals(pagina_esperada)?"Continuar" + pagina_resultante : "Sesion");
					
					if (resultado == "Sesion") {
							
								//Datos de loguero
								driver.findElement(By.id("email")).click();
								wait.Tiempo(2000);
								
								
								driver.findElement(By.id("email")).sendKeys("angel.noriega.m@gmail.com");
								wait.Tiempo(2000);
								
								
								driver.findElement(By.id("passwd")).click();
								wait.Tiempo(2000);
								
								
								driver.findElement(By.id("passwd")).sendKeys("dF20@852t");
								wait.Tiempo(2000);
																			
								//Submit
								driver.findElement(By.xpath("//*[@id=\"SubmitLogin\"]/span")).click();
								wait.Tiempo(3000);
								
								logger.log(Status.INFO, "Usuario Inicia Sesion");
								
					    	} /*else {
					         System.out.println("Sesi�n Iniciada Correctamente");
					         driver.close();
					      }	*/	
						
					//Agregar comentario a pedido - - 03. Address
					logger.log(Status.INFO, "Etapa 03. Address");
					
					driver.findElement(By.tagName("textarea")).click();
					wait.Tiempo(3000);
					
					driver.findElement(By.tagName("textarea")).sendKeys("Este es un comentario a pedido");
					wait.Tiempo(3000);
					
					logger.log(Status.INFO, "Comentario a Pedido");
					
					//Boton de Proceed to chekout - 03. Address
					driver.findElement(By.xpath("//*[@id=\"center_column\"]/form/p/button")).click();
					wait.Tiempo(2000);
					
					
					//Click en Terms of service
					driver.findElement(By.xpath("//*[@id=\"cgv\"]")).click();
					wait.Tiempo(3000);
					
					//Boton de Proceed to chekout - 04. Shipping
					logger.log(Status.INFO, "Etapa 04. Shipping");
					
					driver.findElement(By.xpath("//*[@id=\"form\"]/p/button")).click();
					wait.Tiempo(3000);
					logger.log(Status.INFO, "Acepta Condiciones del servicio - Terms of service");
					
					//Extraigo el valor de la compra - 05. Payment
					String valor_compra = driver.findElement(By.xpath("//*[@id=\"total_price\"]")).getText();
					System.out.println(valor_compra); // extraigo el valor de la compra
					wait.Tiempo(2000);
					
					//Comparo si son iguales los montos antes de pagar la orden
					logger.log(Status.INFO, "Etapa 05. Payment");	
					
					total = (valor_compra.contentEquals(valor_pedido_esperado)?"Continuar" + valor_compra : "Diferencias entre montos");
					
						if (total == "Diferencias entre montos") {				
						System.out.println("Error en diferencias de montos");
						driver.close();
						}
						
					logger.log(Status.INFO, "Montos a pagar validados correctamente");	
					//Click Bot�n Pay by bank wire
					driver.findElement(By.xpath("//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a")).click();
					wait.Tiempo(2000);
					
					//Click Bot�n I confirm my order
					driver.findElement(By.tagName("button")).click();
					wait.Tiempo(3000);
					logger.log(Status.INFO, "Etapa 05. Payment - Flujo completado y pago correcto exitosamente");					
					//System.out.println("Flujo completado y pago correcto exitosamente");
				
	}
				
				
/*---------------------- Ultimo ---------------------*/		
/*---------------------- Ultimo ---------------------*/	

		
	@AfterMethod
		 public void getResult(ITestResult result) throws Exception{
		 if(result.getStatus() == ITestResult.FAILURE){
		 //MarkupHelper is used to display the output in different colors
		 logger.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " - Test Case Failed", ExtentColor.RED));
		 logger.log(Status.FAIL, MarkupHelper.createLabel(result.getThrowable() + " - Test Case Failed", ExtentColor.RED));
		 //To capture screenshot path and store the path of the screenshot in the string "screenshotPath"
		 //We do pass the path captured by this method in to the extent reports using "logger.addScreenCapture" method. 
		 //String Scrnshot=TakeScreenshot.captuerScreenshot(driver,"TestCaseFailed");
		 //String screenshotPath = getScreenShot(driver, result.getName());
		 
		 //To add it in the extent report 
		 //logger.fail("Test Case Failed Snapshot is below " + logger.addScreenCaptureFromPath(screenshotPath));
		 
		 }
		 else if(result.getStatus() == ITestResult.SKIP){
		 logger.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + " - Test Case Skipped", ExtentColor.ORANGE)); 
		 } 
		 else if(result.getStatus() == ITestResult.SUCCESS)
		 {
		 logger.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" Test Case PASSED", ExtentColor.GREEN));
		 }
		 driver.quit();
		 }
		
		
		
	@AfterTest
		public void endReport(){
			extent.flush();
			
	    }	
		
}


