package cliente_registrado_C002;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.NoSuchElementException;

//import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import Time.time;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*; 
import org.junit.Test;
import org.junit.Assert;


/*
 * Esta clase define el caso de prueba "C002 Iniciar sesi�n � Cliente registrado" en la tienda virtual

 * @author: Angel Noriega

 * @version: 1.0
 
 * @Fecha: 30/12/2020
 
 */


public class cliente_registrado {
	
	 public static void main(String[] args) { 
		
		time tiempo = new time();
		 
		WebDriver driver;
		String baseUrl= "http://automationpractice.com/index.php"; //Url de la p�gina que va abrir en el navegador
		String chromePath = System.getProperty("webdriver.chrome.driver","C:\\Users\\Fabricio\\eclipse\\java-2020-12\\eclipse\\chromedriver.exe"); 
			
		System.setProperty("webdriver.chrome.driver", chromePath); 
				
		driver = new ChromeDriver(); 
		driver.get(baseUrl); 
		driver.manage().window().maximize(); //abrir la ventana full tama�o
		tiempo.Tiempo(2000);
		 
		String pagina_esperada = "My account - My Store";
		String pagina_resultante = "";
		 
		 	 
/*		time tiempo = new time();		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Fabricio\\eclipse\\java-2020-12\\eclipse\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize(); //abrir la ventana full tama�o
		driver.get("http://automationpractice.com/index.php"); //Url de la p�gina que va abrir
		tiempo.Tiempo(2000);
		

		*/
		
				
		driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
		tiempo.Tiempo(2000);

		//Datos del formulario de loguero
		
		/*Email*/
		driver.findElement(By.id("email")).click();
		tiempo.Tiempo(2000);
		
		
		driver.findElement(By.id("email")).sendKeys("angel.noriega.m@gmail.com");
		tiempo.Tiempo(2000);
		
		/*Password*/
		driver.findElement(By.id("passwd")).click();
		tiempo.Tiempo(2000);
		
		driver.findElement(By.id("passwd")).sendKeys("dF20@852t");
		tiempo.Tiempo(2000);
		
							
		//Submit
		driver.findElement(By.xpath("//*[@id=\"SubmitLogin\"]/span")).click();
		tiempo.Tiempo(3000);

		//if (driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]")))
		
		/*	try {
				boolean eleSelected= driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]")).isDisplayed();
							   
			 } catch (InterruptedException e) {
			    	e.printStackTrace();
			    	
			    }*/
				
		pagina_resultante = driver.getTitle(); //obtengo el valor del t�tulo de la pagina para compararlo con el valor esperado
		System.out.println(pagina_resultante.contentEquals(pagina_esperada)?"Prueba Pasada - Sesi�n Iniciada Correctamente " + pagina_resultante : "Prueba Fallada -Sesi�n FALLADA");
		driver.close();
		
/*		
		
		boolean eleSelected= driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]")).isDisplayed();
		         
		System.out.println("\nEl valor de eleSelected es: " + eleSelected);
		
		 if (eleSelected == false) {
			 	System.out.println("Sesi�n FALLADA");
				driver.close();
	        } else {
	            System.out.println("Sesi�n Iniciada Correctamente");
	            driver.close();
	        }
*/		
		
								//revisar con if
		 						//Esto funciona
					/*			try { //driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]")).isDisplayed();
									boolean eleSelected= driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]")).isDisplayed();
									System.out.println(eleSelected);
									
								} catch (NoSuchElementException e) {
									e.printStackTrace();
									System.out.println("Sesi�n FALLADA");
									driver.close();
								}
									 
						  
							System.out.println("Sesi�n iniciada correctamente");
							driver.close();
					*/	
	 }

  }			
		
		
		
	

